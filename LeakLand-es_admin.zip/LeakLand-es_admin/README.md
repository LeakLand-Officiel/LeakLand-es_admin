# es_admin

An EssentialMode plugin that adds advanced administration capabilities to your FiveM server

Hint: rename to "es_admin2" to make the GUI work.
